﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IBirthdable
    {
        public string BirthDay { get; }
    }
}
